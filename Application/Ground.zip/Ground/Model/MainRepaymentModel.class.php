<?php
namespace Admin\Model;
use Think\Model;

/**
 * 还款信息模型
 */

class MainRepaymentModel extends Model {

}
