<?php
// +----------------------------------------------------------------------
// | OneThink [ WE CAN DO IT JUST THINK IT ]
// +----------------------------------------------------------------------
// | Copyright (c) 2013 http://www.onethink.cn All rights reserved.
// +----------------------------------------------------------------------
// | Author: waco <etoupcom@126.com> <http://www.etoup.com>
// +----------------------------------------------------------------------

namespace Ground\Controller;

/**
 * 订单管理控制器
 * @author waco <etoupcom@126.com>
 */

class OrdersController extends AdminController {

	/**
	 * 场馆管理首页
	 * @author waco <etoupcom@126.com>
	 */
	public function index() {
        $venue_items = D('VenueItemsView')->where(['vid'=>VID])->select();
        $this->venue_items = $venue_items;
        if(!empty($venue_items)){
            $orders_date = I('get.d','');
            if($orders_date){
                $date = $orders_date;
                $week = date('D',strtotime($orders_date));
            }else{
                $date = date('Y-m-d');
                $week = date('D');
            }
            $getweeks = $this->getWeeks();
            foreach($venue_items as $k => $v){
                //时间
                $venue_items[$k]['date_week'] = $date.' '.$getweeks[$week];
                //获取时间节点
                $venue_items[$k]['nodes'] = $this->getTimeNode($v['start'],$v['end'],$v['duration']);
                //获取场地信息
                $blocks = M('VenueBlock')->where(['vid'=>VID,'items_id'=>$v['items_id']])->select();
                $venue_items[$k]['blocks'] = $blocks;
                if(!empty($blocks)){
                    foreach($blocks as $key=>$val){
                        //获取价格
                        $prices = M('OrdersTemp')->where(['vid'=>VID,'items_id'=>$v['items_id'],'bid'=>$val['id'],'week'=>$week])->select();
                        if(!empty($prices)){
                            foreach($prices as $kp=>$vp){
                                if($info = M('Orders')->where(['tid'=>$vp['id'],'nodes'=>$date])->find()){
                                    $prices[$kp]['has_order'] = true;
                                    $prices[$kp]['order_id'] = $info['id'];
                                }
                            }
                        }
                        $venue_items[$k]['blocks'][$key]['prices'] = $prices;
                    }
                }
            }
        }
        $this->list = $venue_items;
        $this->pre_date = date('Y-m-d', strtotime('-1 day',strtotime($date)));
        $this->next_date = date('Y-m-d', strtotime('+1 day',strtotime($date)));
        //p($venue_items);
        $this->active = 'Index_index';
		$this->meta_title = '订单管理';
		$this->display();
	}

    public function lists(){
        $this->list = M('Orders')->where(['vid'=>VID])->select();
        $this->meta_title = '订单管理列表';
        $this->display();
    }

    public function ordersview(){
        $id = I('get.id',0,'int');
        $id or $this->error('请选择操作项');
        $this->info = D('OrdersView')->find($id);
        //p($this->info,0);
        $this->display();
    }

    public function reserves(){
        $id = I('post.id',[]);
        $id or $data_id = ['status'=>false,'msg'=>'请选择操作项'];
        if($data_id){
            $this->ajaxReturn($data_id);
        }
        $mobile = I('post.mobile','');
        $mobile or $data_mobile = ['status'=>false,'msg'=>'请填写预定人手机号码'];
        if(!check_mobile($mobile)){
            $data_mobile = ['status'=>false,'msg'=>'请正确填写预定人手机号码'];
        }
        if($data_mobile){
            $this->ajaxReturn($data_mobile);
        }
        $bid = M('OrdersTemp')->where(['id'=>['in',$id],'vid'=>VID])->select();
        if($bid){
            foreach($bid as $k=>$v){
                $mod = D('Orders');
                $mod->addData([
                    'uid'=>UID,
                    'items_id'=>$v['items_id'],
                    'vid'=>$v['vid'],
                    'bid'=>$v['bid'],
                    'tid'=>$v['id'],
                    'start'=>$v['start'],
                    'end'=>$v['end'],
                    'price'=>$v['price'],
                    'status'=>1,
                    'types'=>1,
                    'mobile'=>$mobile
                ]);
            }
            $this->ajaxReturn(['status'=>true,'msg'=>'操作成功']);
        }else{
            $this->ajaxReturn(['status'=>false,'msg'=>'操作失败']);
        }
    }

    private function getTimeNode($start,$end,$duration){
        $node = ceil((strtotime($end)-strtotime($start))/($duration*60));
        for($i=0;$i<$node;$i++){
            $date_time_start = strtotime('+'.$duration*$i.' minutes',strtotime($start));
            $date_time_end = strtotime('+'.$duration*($i+1).' minutes',strtotime($start));
            $time_node[] = [
                'start'=>date('H:i',$date_time_start),
                'end'=>date('H:i',$date_time_end)
            ];
        }
        return $time_node;
    }

    private function getWeeks(){
        return [
            'Mon'=>'星期一',
            'Tue'=>'星期二',
            'Wed'=>'星期三',
            'Thu'=>'星期四',
            'Fri'=>'星期五',
            'Sat'=>'星期六',
            'Sun'=>'星期日'
        ];
    }
}
